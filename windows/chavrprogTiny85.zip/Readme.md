# chavrprogTiny85.exe
by [Hilmar](https://github.com/HilmarSt)

A **Windows64 executable** for programming an **ATtiny85** with a **CH340** programmer. Other Atmel devices should also work but are not tested.  
With *cygwin1.dll* and *libusb-1.0.dll* it will run without the installation of Cygwin64.

Based on [chavrprog](https://github.com/Trel725/chavrprog) with the following **modifications:**

* ignores `libusb_detach_kernel_driver()` errors (will be printed as "hxs (retval)")
* fills the (falsely twice written) first written first 2 bytes of the first flash page with 0xFF (will be printed as " X ")
* changes the `usleep()` delay after a flash page write from 4500 to 18000 (may work with a lower value)
